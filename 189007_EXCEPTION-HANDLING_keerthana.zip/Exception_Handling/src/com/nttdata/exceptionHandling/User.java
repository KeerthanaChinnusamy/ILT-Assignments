package com.nttdata.exceptionHandling;

public class User {
	private String userName;
	private Account account;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public User(String userName, Account account) {
		super();
		this.userName = userName;
		this.account = account;
	}
	@Override
	public String toString() {
		return "User [userName=" + userName + ", account=" + account + "]";
	}
	
}
