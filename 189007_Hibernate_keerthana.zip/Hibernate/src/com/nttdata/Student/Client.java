package com.nttdata.Student;

import java.util.Iterator;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.List;

import com.nttdata.oneToMany.Category;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration config=new Configuration();
		config.configure("HibernateConfig.xml");
		
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();
		
		Student student=new Student();
		student.setStudentId(2);
		student.setStudentName("Sandhya");
		Transaction tx=sess.beginTransaction();
		sess.save(student);
		Object obj=sess.get(Student.class, new Integer(10));
		Student s1=(Student)obj;
		
		Query query=sess.createQuery("from Student");
		java.util.List list =query.list();
		Iterator it=list.iterator();
		while(it.hasNext())
		{
			Object o=it.next();
			Student stu=(Student)o;
			System.out.println("Student Details:"+stu.getStudentId()+"\t"+stu.getStudentName());
		}
		
		tx.commit();
		sess.close();
		System.out.println("Student call done..");
		sf.close();
	}

}
