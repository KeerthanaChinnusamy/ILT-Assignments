package com.nttdata.manyToOne;

public class Category {
private int categId;
private String categName;
public int getCategId() {
	return categId;
}
public void setCategId(int categId) {
	this.categId = categId;
}
public String getCategName() {
	return categName;
}
public void setCategName(String categName) {
	this.categName = categName;
}

}
