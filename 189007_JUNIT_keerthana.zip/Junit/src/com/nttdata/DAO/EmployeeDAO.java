package com.nttdata.DAO;

import java.util.List;

import com.nttdata.Model.Employee;

public interface EmployeeDAO {
static Employee getByEmployeeId(int id) {
	// TODO Auto-generated method stub
	return null;
}
static Employee createEmployee() {
	// TODO Auto-generated method stub
	return null;
}
static Employee deleteEmployee(int id) {
	// TODO Auto-generated method stub
	return null;
}
static List<Employee> listEmployee() {
	// TODO Auto-generated method stub
	return null;
}
static Employee searchEmployeeByName(String name) {
	// TODO Auto-generated method stub
	return null;
}
}
