package com.nttdata.DAOImpl;

import java.util.List;

import com.nttdata.DAO.EmployeeDAO;
import com.nttdata.Model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{

	public Employee getByEmployeeId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee createEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> listEmployee() {
		// TODO Auto-generated method stub
		return null;
	}


	public Employee searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
