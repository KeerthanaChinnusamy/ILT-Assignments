package OpenClosedPrinciple;

public interface Shape {
	public double calculateArea();
}
