package com.nttdata;

import java.util.ArrayList;
import java.util.List;
 

 
public class StreamFilterEx {
 
    public static void main(String a[]) {
 
        List<Employee> empList = new ArrayList<>();
        empList.add(new Employee("e1", "Nataraja G", 8000));
        empList.add(new Employee("e2", "Nagesh Y", 15000));
        empList.add(new Employee("e3", "Vasu V", 2500));
        empList.add(new Employee("e4", "Amar", 12500));
 
        // find employees whose salaries are above 10000
        empList.stream().filter(emp->emp.getSalary() > 10000).forEach(System.out::println);
        long l= empList.stream().filter(emp->emp.getSalary() > 10000).count();
        System.out.println("Number of employees have salary more than 10000 is:"+l);
    }
}