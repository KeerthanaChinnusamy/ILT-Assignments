package com.ntt.vehicle;

public class Bike extends Vehicle{
	
	public void displayDetails()
	{
		Vehicle vehicle=new Vehicle();
		vehicle.setNumber(234);
		vehicle.setName("HONDA");
		vehicle.setPrice(35000);
		System.out.println(vehicle.toString());	
	}
	public void start()
	{
		System.out.println("Bike started");
	}
	public void stop()
	{
		System.out.println("Bike stopped");
	}
}
