package com.ntt.vehicle;

public class Bus extends Vehicle{
	
	public void displayDetails()
	{
		Vehicle vehicle=new Vehicle();
		vehicle.setNumber(456);
		vehicle.setName("KPN");
		vehicle.setPrice(50000);
		System.out.println(vehicle.toString());	
	}
	public void start()
	{
		System.out.println("Bus started");
	}
	public void stop()
	{
		System.out.println("Bus stopped");
	}
}
