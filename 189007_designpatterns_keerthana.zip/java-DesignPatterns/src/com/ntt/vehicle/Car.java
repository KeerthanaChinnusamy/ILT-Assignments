package com.ntt.vehicle;

public class Car extends Vehicle{
	
	public void displayDetails()
	{
		Vehicle vehicle=new Vehicle();
		vehicle.setNumber(123);
		vehicle.setName("HONDA");
		vehicle.setPrice(100000);
		
		System.out.println(vehicle.toString());	
	}
	public void start()
	{
		System.out.println("Car started");
	}
	public void stop()
	{
		System.out.println("Car stopped");
	}
}
